<?php

function tracking() {
    ?>
    <html>
    <head>
        <title>BiTechX Test</title>
        <link rel="shortcut icon" type="image/png" href="https://bitechx.com/images/favicon/bitechx.png">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <!-- Data Table CSS & JS -->
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.foundation.min.css">
        <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.21/js/dataTables.foundation.min.js"></script>

    </head>
    
        
   
            <?php

            global $wpdb;
            $table_name = $wpdb->prefix . 'tracking';
            $employees = $wpdb->get_results("SELECT * from $table_name");
          ?>
           <body>
        
               
            <table class="table table-striped table-bordered mx-auto pt-5" style="width:100%;max-width:1200px;border: 2px solid black;border-collapse: collapse;" >
                <thead>
                    <tr>
                        <th colspan="3" style="text-align: center;">After Edit</th>
                        <th colspan="3" style="text-align: center;">Before Edit</th>
                        <th  rowspan="2" style="text-align: center;">Timetable of Edit  </th> 
                    </tr>
                    <tr>
                        <th style="text-align: center;">Email</th>
                       
                        <th style="text-align: center;">Password</th>
                        <th style="text-align: center;">File</th>
                        <th style="text-align: center;">Previous Email</th>
                        <th style="text-align: center;"> Previous Password</th>
 
                        
                        <th style="text-align: center;" >Previous File</th>
                       
                      
                     
                    </tr>
                    
                    <tbody>
                        <?php 
            foreach ($employees as $employee) {
                
                ?>
               
                        <tr>
                            <td><?php echo  "$employee->Email";  ?></td>
                              <td><?php echo  "$employee->Password";  ?></td>
                               <td><?php echo  "$employee->File";  ?></td>
                         
                            <td><?php echo  "$employee->Prevemail";?></td>
                        
                            <td><?php echo  "$employee->prevpass";?></td>
                              <td><?php echo  "$employee->prevfile";?></td>
                            <td><?php echo  "$employee->timee";  ?></td>
                           
                    
                   

                        </tr>
                    </tbody>
                </thead>
          
            <?php } ?>
              </table>
        </div>
    </body>
</html>
           
        
 
    <?php

}
//add_shortcode('short_employee_list', 'employee_list');
?>