<?php
/**
 * Created by PhpStorm.
 * User: lcom53-two
 * Date: 2/12/2018
 * Time: 2:25 PM
 */
function employee_insert()
{
    //echo "insert page";
    ?>

<html>
    <head>
        <title>BiTechX Test</title>
        <link rel="shortcut icon" type="image/png" href="https://bitechx.com/images/favicon/bitechx.png">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <!-- Data Table CSS & JS -->
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.foundation.min.css">
        <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.21/js/dataTables.foundation.min.js"></script>

    </head>
    <body>
        <div class="container">
            <h1 class="text-center">BiTechX Test</h1>
            <form method="post" class="mx-auto pt-5" style="max-width:700px;" >
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" required="required" pattern="[^@]+@[^\.]+\..+" title="One . and @ is required" placeholder="zahinewu@gmail.com">
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{5,}" required="required" title="Must contain at least one number and one uppercase and lowercase letter, and at least 5 or more characters" placeholder="9Zahin">
                </div>
                <div class="form-group">
                    <label>Upload file</label>
                    <input type="file" class="form-control-file" name="file" required="required">
                </div>
                <button type="submit" class="btn btn-primary" name="ins">Submit</button>
            </form>
            
        </div>
    </body>
</html>
<?php
    if(isset($_POST['ins'])){
      global $wpdb;
        $Email=$_POST['email'];
        $Password=$_POST['password'];
        $File=$_POST['file'];
        $table_name = $wpdb->prefix . 'employee';

        $wpdb->insert(
            $table_name,
            array(
                'Email' => $Email,
                'Password' => $Password,
                'File' => $File
            ),$format=NULL
        );
        
         ?>
         <script type="text/javascript">
        alert("inserted! Go to Employee Listing to view the insertion ");
    </script>

        <?php
        exit;
    }
    ?>
    
    <?php
}

?>
