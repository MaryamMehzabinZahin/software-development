<?php
/**
 * Plugin Name:       CRUD Plugin
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       Custom Plugin to create crud operation.
 * Version:           1.10.3
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Maryam Mehzabin Zahin
 * Author URI:        https://github.com/MaryamMehzabinZahin/Course-Projects
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       my-custom-plugin
 
 */
/////
global $jal_db_version;
$jal_db_version = '1.0';

function jal_install() {
    global $wpdb;
    global $jal_db_version;

    $table_name = $wpdb->prefix . 'employee';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		
		Email varchar(40) NOT NULL,
		Password varchar(40) NOT NULL,
        File LONGBLOB not null,
		 
		PRIMARY KEY  (id)
	) $charset_collate;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
     $table_name = $wpdb->prefix . 'tracking';
   
    $sql = "CREATE TABLE $table_name (
        cid mediumint(9) NOT NULL AUTO_INCREMENT,
        
        Email varchar(40) NOT NULL,
        Prevemail varchar(40) NOT NULL,
        Password varchar(40) not null,
        prevpass varchar(40) not null,
        File LONGBLOB not null,
        prevfile LONGBLOB not null,
        timee TIMESTAMP,

        PRIMARY KEY  (cid)
    ) $charset_collate;";
 
     require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
     dbDelta( $sql );

    add_option( 'jal_db_version', $jal_db_version );
}

register_activation_hook( __FILE__, 'jal_install' );
//adding in menu
add_action('admin_menu', 'at_try_menu');

function at_try_menu() {
    //adding plugin in menu
    add_menu_page('employee_list', //page title
        'Employee Listing', //menu title
        'manage_options', //capabilities
        'Employee_Listing', //menu slug
        'employee_list' //function
    );
    //adding submenu to a menu
    add_submenu_page('Employee_Listing',//parent page slug
        'employee_insert',//page title
        'Employee Insert',//menu titel
        'manage_options',//manage optios
        'Employee_Insert',//slug
        'employee_insert'//function
    );
    add_submenu_page('Employee_Listing',//parent page slug
        'tracking',//page title
        'Tracking change ',//menu titel
        'manage_options',//manage optios
        'tracking_change',//slug
        'tracking'//function
    );
    add_submenu_page( null,//parent page slug
        'employee_update',//$page_title
        'Employee Update',// $menu_title
        'manage_options',// $capability
        'Employee_Update',// $menu_slug,
        'employee_update'// $function
    );
    add_submenu_page( null,//parent page slug
        'employee_delete',//$page_title
        'Employee Delete',// $menu_title
        'manage_options',// $capability
        'Employee_Delete',// $menu_slug,
        'employee_delete'// $function
    );
    
}
// returns the root directory path of particular plugin
define('ROOTDIR', plugin_dir_path(__FILE__));
require_once(ROOTDIR .'employee_list.php');
require_once (ROOTDIR.'employee_insert.php');

require_once (ROOTDIR.'employee_update.php');
require_once (ROOTDIR.'employee_delete.php');
require_once(ROOTDIR.'tracking_change.php')
?>
