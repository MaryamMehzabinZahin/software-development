<?php
//echo "employee delete";
function employee_delete(){
   
    if(isset($_GET['id'])){
        global $wpdb;
        $table_name=$wpdb->prefix.'employee';
        $i=$_GET['id'];
        $wpdb->delete(
            $table_name,
            array('id'=>$i)
        );
       
    }
   
    ?>
    <script type="text/javascript">
        alert("Deleted! Go to Employee Listing to view the deletion ");
    </script>
   
    <?php
    
}

?>