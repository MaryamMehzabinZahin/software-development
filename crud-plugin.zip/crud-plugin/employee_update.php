<?php
//echo "update page";
function employee_update(){
    //echo "update page in";
    $i=$_GET['id'];
    global $wpdb;
    $table_name = $wpdb->prefix . 'employee';
    $employees = $wpdb->get_results("SELECT * from $table_name where id=$i");
    $prevemail=$employees[0]->Email;
    $prevpass=$employees[0]->Password;
   
    $prevfile=$employees[0]->File;  

    ?>
 
    <html>
    <head>
        <title>BiTechX Test</title>
        <link rel="shortcut icon" type="image/png" href="https://bitechx.com/images/favicon/bitechx.png">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <!-- Data Table CSS & JS -->
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.foundation.min.css">
        <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.21/js/dataTables.foundation.min.js"></script>

    </head>
    
        <body>
            <div class="container">
           
         <form name="frm" action="#" method="post" class="mx-auto pt-5" style="max-width:700px;">
          
            <input type="hidden" name="id" value="<?= $employees[0]->id; ?>">
            <input type="hidden" name="prevemail" value="<?= $employees[0]->Email;?>">
            <input type="hidden" name="prevpass" value="<?= $employees[0]->Password;?>">
            <input type="hidden" name="prevfile" value="<?= $employees[0]->File;?>">

           <div class="form-group">
                <label>Email</label>
               <input type="email" name="email" class="form-control" required="required" 
               pattern="[^@]+@[^\.]+\..+" title="One . and @ is required" placeholder="zahinewu@gmail.com"></div>
          <div class="form-group">
                <label>Password</label>
                <input type="text" name="password" class="form-control" required="required" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{5,}"  title="Must contain at least one number and one uppercase and lowercase letter, and at least 5 or more characters" placeholder="9Zahin"></div>
           <div class="form-group"> 
                <label>Upload file</label>
                <input type="File" name="file" class="form-control-file" required="required" ></div>
            
                 <button type="submit" class="btn btn-primary" name="upd">Submit</button>
            
        </form>
       </div>
   </body>
</html>


    <?php
}
if(isset($_POST['upd']))
{
    global $wpdb;
    $table_name=$wpdb->prefix.'tracking';

    $id=$_POST['id'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $prevemail=$_POST['prevemail'];
    $prevpass=$_POST['prevpass'];
    $prevfile=$_POST['prevfile'];
    $file=$_POST['file'];
    $wpdb->insert(
            $table_name,
            array(
                'Email' => $email,
                'Prevemail' => $prevemail,
                'Password'=>$password,
                'prevpass'=> $prevpass,
                'File'=>$file,
                'prevfile'=>$prevfile

               
            ),
        );
     $table_name=$wpdb->prefix.'employee';

    $wpdb->update(
        $table_name,
        array(
            'Email'=>$email,
            'password'=>$password,
            'file'=>$file
        ),
        array(
            'id'=>$id
        )
    ); ?>
    <script type="text/javascript">
        alert("updated! Go to Employee Listing to view the edit operation ");
    </script>
    <?php
    
}
?>