<?php

function employee_list() {
    ?>
    <html>
    <head>
        <title>BiTechX Test</title>
        <link rel="shortcut icon" type="image/png" href="https://bitechx.com/images/favicon/bitechx.png">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <!-- Data Table CSS & JS -->
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.foundation.min.css">
        <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.21/js/dataTables.foundation.min.js"></script>

    </head>
    
        
   
            <?php

            global $wpdb;
            $table_name = $wpdb->prefix . 'employee';
            $employees = $wpdb->get_results("SELECT Email,id from $table_name");
          ?>
           <body>
        
               
            <table class="table table-striped table-bordered mx-auto pt-5" style="width:100%;max-width:700px;">
                <thead>
                    <tr>
                        <th>Email</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    <tbody>
                        <?php 
            foreach ($employees as $employee) {
                
                ?>
               
                        <tr>
                            <td><?php echo  "$employee->Email";  ?></td>
                    
                    <td><a href="<?php echo admin_url('admin.php?page=Employee_Update&id=' . $employee->id); ?>"><button class="btn btn-primary">Edit </button></a></td>
                    <td><a href="<?php echo admin_url('admin.php?page=Employee_Delete&id=' . $employee->id); ?>"> <button class="btn btn-danger">Delete</button></a></td>

                        </tr>
                    </tbody>
                </thead>
          
            <?php } ?>
              </table>
        </div>
    </body>
</html>
           
        
 
    <?php

}
//add_shortcode('short_employee_list', 'employee_list');
?>